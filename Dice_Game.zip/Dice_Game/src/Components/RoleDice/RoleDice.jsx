
import { useState } from "react";
import styles from "./RoleDice.module.css";

const RoleDice = ({currDice, diceRole, setScore}) => {

    const resetScore = () =>{
        setScore(0);
    }

    const [rule, setRule] = useState(false);

    const rules = () => {
        setRule(!rule);
    }
    
    return(
        <div className={styles.container}>
            <img onClick={diceRole} id={styles.img} src={`dice${currDice}.png`}/>
            <p>Click on Dice to roll</p>
            <button onClick={resetScore}>Reset Score</button>
            <button onClick={rules}>Show Rules</button>
 
            {rule && <div className={styles.rules}>
                <h2>How to play Dice game</h2>
                <ul>
                    <li>Select any number</li>
                    <li>Click on dice image</li>
                    <li>after click on dice if selected number is equal to dice number you will get same point as dice{" "}</li>
                    <li>if you get wrong guess then 2 point will be deducated</li>
                </ul>
            </div>}

        </div>
    );
};

export default RoleDice;