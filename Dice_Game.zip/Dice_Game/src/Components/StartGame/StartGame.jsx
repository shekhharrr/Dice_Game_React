import styles from "./StartGame.module.css";

const StartGame = (props) => {

    return(
        <div className={styles.container}>
            <div className={styles.dice_img}>
                <img src="dice.jpg" alt="" />
            </div>
            <div className={styles.dice_play}>
            <p>Shekhar's</p>
                <h1>DICE GAME</h1>
                <button onClick={props.toggle}>Play now</button>
            </div>
        </div>
    );
};

export default StartGame;