import { useState } from "react";
import StartGame from "./StartGame/StartGame";
import GamePlay from "./GamePlay/GamePlay";

const HDice = () => {

    const [start, setStart] = useState(false);

    const toggleStart = () => {
        setStart(!start);
    }

    return(
        <div>
            {start ? <GamePlay /> : <StartGame toggle={toggleStart} />}
        </div>
    );
};

export default HDice;