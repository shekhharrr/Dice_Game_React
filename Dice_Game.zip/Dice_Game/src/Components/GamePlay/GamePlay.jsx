import { useState } from "react";
import styles from "./GamePlay.module.css";
import RoleDice from "../RoleDice/RoleDice";

const GamePlay = () => {

    let arrs = [1,2,3,4,5,6];

    const numSelHandler = (arr) => {
        setNum(arr);
        setError("");
    }

    const [score, setScore] = useState(0);
    const [error, setError] = useState("");

    const [num, setNum] = useState(1);
    const [currDice, setCurrDice] = useState(1);

    const genrNum = (max, min) => {
        return Math.floor(Math.random() * (max - min) + min);
    };

    const diceRole = () => {

        if(!num){
            setError("You have not selected any number");
            return;
        }
        setError("");

        const chngDice = genrNum(1,7);
        setCurrDice((prev)=>chngDice);

        if(num === chngDice){
            setScore((prev)=>prev + chngDice);
        }
        else {
            setScore((prev)=>prev - 2);
        }

        setNum(undefined);
    };
     
    return(
            <div className={styles.container}>
                <div className={styles.score}>
                    <h1>{score}</h1>
                    <p>Total Score</p>
                </div>

                    <p id={styles.err}>{error}</p>
                <div className={styles.boxes}>
                    {arrs.map((arr,i)=>(
                        <box style={{backgroundColor: arr === num ? "black" : "white", color: arr === num ? "white" : "black"}} key={i} onClick={()=>numSelHandler(arr)}>
                            {arr}   
                        </box> 
                    ))}
                </div>
                <p id={styles.p}>Select Number</p>
                <RoleDice setScore={setScore} currDice={currDice} diceRole={diceRole} />
            </div>
    );
};

export default GamePlay;